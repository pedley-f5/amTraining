#!/bin/bash

set -Eeuo pipefail

TOOLS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" &> /dev/null && pwd)"

BASE64_DECODE="-D"

ret=0
echo "dGVzdA==" | base64 ${BASE64_DECODE} > /dev/null 2>&1 || ret=$?
if [ $ret -ne 0 ]; then
    BASE64_DECODE="--decode"
fi

auth_info="$(awk '/\.dockerconfigjson/ { print $2 }' \
    "$TOOLS_DIR/../manifests/charts/base/templates/pullsecret.yaml" \
        | base64 ${BASE64_DECODE} | jq -r '.auths."quay.io".auth' \
        | base64 ${BASE64_DECODE})"

username="$(echo "$auth_info" | cut -d':' -f1)"
password="$(echo "$auth_info" | cut -d':' -f2)"
echo "$password" | docker login -u "$username" --password-stdin quay.io
