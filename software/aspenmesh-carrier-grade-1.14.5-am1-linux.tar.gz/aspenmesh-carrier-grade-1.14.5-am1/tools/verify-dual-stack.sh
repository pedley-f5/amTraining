#!/usr/bin/env bash

# To run this script you must pass in namespace where you want to check
# if the pods running in it are ready for dual-stack use.
#
# This script is used to verify that the control-plane and data-plane
# is configured properly for dual-stack use. The user must pass in the
# data-plane namespace that they want validated. This script will only
# check istio-system for the control-plane verification.
#
# This script also determines how applications in the mesh expose a Service bind.
# When migrating to dual-stack, for proper routing an application must agree
# with its define Service resource. For instance, if a Service is defined
# as 'ipFamilies: [IPv4, IPv6]', but that server application is
# only bound to '0.0.0.0' and is not bound to '[::]', then any client
# request done over IPv6 will result in a 50x error.
#
# Dependencies on host: kubectl, istioctl, oc.
# Dependencies on mesh: Only debug sidecar proxies are supported. This script supports only Aspen Mesh 1.11.8-am2+.
# This will `exec` into the proxy, but only run ss, so it should be suitable to run in a live cluster.

red='\x1B[0;31m'
blue='\x1B[0;34m'
green='\x1B[0;32m'
yellow='\x1B[0;33m'
clr='\x1B[0m'

function vercomp () {
    if [[ $1 == "$2" ]]
    then
        return 0
    fi
    local IFS=.
    # shellcheck disable=2206
    local i ver1=($1) ver2=($2)
    # fill empty fields in ver1 with zeros
    for ((i=${#ver1[@]}; i<${#ver2[@]}; i++))
    do
        ver1[i]=0
    done
    for ((i=0; i<${#ver1[@]}; i++))
    do
        if [[ -z ${ver2[i]} ]]
        then
            # fill empty fields in ver2 with zeros
            ver2[i]=0
        fi
        if ((10#${ver1[i]} > 10#${ver2[i]}))
        then
            return 1
        fi
        if ((10#${ver1[i]} < 10#${ver2[i]}))
        then
            return 2
        fi
    done
    return 0
}

if ! command -v kubectl --help &> /dev/null
then
    echo "kubectl could not be found"
    exit 1
fi

if ! command -v istioctl --help &> /dev/null
then
    echo "istioctl could not be found"
    exit 1
fi

if ! command -v oc --help &> /dev/null
then
    echo "oc could not be found"
    exit 1
fi

NS=default
if [ "$1" != "" ]
then
  NS=${1}
fi

namespaceStatus=$(kubectl get ns "${NS}" --template '{{.status.phase}}')
if [ "$namespaceStatus" != "Active" ]
then
  echo "Namespace ${NS} is not present. Exiting..."
  exit 1
fi

echo "Verifying that you are installing this on at least OpenShift 4.8"
ocversion="$(oc get clusterversion --template '{{range .items}}{{.status.desired.version}}{{end}}')"
vercomp 4.8.0 "${ocversion}"
if [[ $? == 1 ]]
then
    echo -e "${red}Aspen Mesh dual-stack requires OpenShift 4.8.0+${clr}"
    echo -e "${red}Current version of OpenShift: ${ocversion}${clr}"
    exit 1
else
    echo -e "${green}Current version of OpenShift meets the minimimum requirement of 4.8.0+. Version: ${ocversion}${clr}"
fi
echo

echo "Verifying OpenShift is running in dual-stack mode"
network="$(oc get network --template '{{range .items}}{{.status.networkType}}{{end}}')"
if [ "${network}" != "OVNKubernetes" ]; then
  echo -e "${red}OpenShift CNI is not set to OVNKubernetes${clr}"
  echo -e "${red}Current CNI: ${network}${clr}"
  exit 1
fi
echo -e "${green}OVNKubernetes CNI is configured${clr}"

# shellcheck disable=2016
cidrs="$(oc get network --template '{{range .items}}{{range $f := .status.clusterNetwork}}{{$f.cidr}} {{end}}{{end}}')"
ipv4=false
ipv6=false
for cidr in ${cidrs}; do
  if [[ "${cidr}" == *":"* ]]; then
    ipv6=true
  elif [[ "${cidr}" == *"."* ]]; then
    ipv4=true
  fi
done
if [ ! ${ipv4} ] || [ ! $ipv6 ]; then
  echo -e "${red}OVNKubernetes only configured for one CIDR block (not both IPv4 and IPv6): [ ${cidrs} ]${clr}"
  exit 1
fi
echo -e "${green}OVNKubernetes CNI can assign IPv4 and IPv6 addresses over CIDR ranges: [ ${cidrs} ]${clr}"
echo

echo "Verifying the control-plane..."
pods="$(kubectl get pods -l app=istiod -n istio-system --template '{{range .items}}{{.metadata.name}} {{end}}')"
for pod in ${pods}; do
  echo "Checking istio-system/${pod}..."
  dsenv=$(kubectl get pods -n istio-system "${pod}" --template '{{range .spec.containers}}{{range .env}}{{if eq .name "ISTIO_DUAL_STACK"}}{{.value}}{{"\n"}}{{end}}{{end}}{{end}}')
  if [ "${dsenv}" == "true" ]; then
    echo -e "  ${green}Environment variable ISTIO_DUAL_STACK is enabled for istio-system/${pod}${clr}"
  else
    echo -e "  ${red}Environment variable ISTIO_DUAL_STACK is not set or is disabled for istio-system/${pod}${clr}"
    echo -e "${red}control-plane is NOT configured for dual-stack${clr}"
    echo -e "${red}Please re-install Aspen Mesh with the overrides value properly set for dual-stack use${clr}"
    exit 1
  fi
done
echo -e "${green}...ISTIO_DUAL_STACK environment variable is set in the control-plane${clr}"

for pod in ${pods}; do
  echo "Checking istio-system/${pod}..."
  dsenv=$(kubectl get pods -n istio-system "${pod}" --template '{{range .spec.containers}}{{range .env}}{{if eq .name "PILOT_USE_ENDPOINT_SLICE"}}{{.value}}{{"\n"}}{{end}}{{end}}{{end}}')
  if [ "${dsenv}" == "true" ]; then
    echo -e "  ${green}Environment variable PILOT_USE_ENDPOINT_SLICE is enabled for istio-system/${pod}${clr}"
  else
    echo -e "  ${red}Environment variable PILOT_USE_ENDPOINT_SLICE is not set or is disabled for istio-system/${pod}${clr}"
    echo -e "${red}control-plane is NOT configured for dual-stack${clr}"
    echo -e "${red}Please re-install Aspen Mesh with the overrides value properly set for dual-stack use${clr}"
    exit 1
  fi
done
echo -e "${green}...PILOT_USE_ENDPOINT_SLICE environment variable is set in the control-plane${clr}"

echo
echo -e "${green}The control-plane is configured properly for dual-stack use${clr}"
echo

echo "Verifying that each pod in ${NS} is configured for dual-stack use..."
pods="$(kubectl get pods -l security.istio.io/tlsMode=istio -n "${NS}" --template '{{range .items}}{{.metadata.name}} {{end}}')"
for pod in ${pods}; do
  echo "Checking ${NS}/${pod}..."
  dsenv=$(kubectl get pods -n "${NS}" "${pod}" --template '{{range .spec.containers}}{{range .env}}{{if eq .name "ISTIO_AGENT_DUAL_STACK"}}{{.value}}{{"\n"}}{{end}}{{end}}{{end}}')
  if [ "${dsenv}" == "true" ]; then
    echo -e "  ${green}Environment variable ISTIO_AGENT_DUAL_STACK is enabled for ${NS}/${pod}${clr}"
  else
    echo -e "${red}Please restart the affected pods${clr}"
    exit 1
  fi
done

echo
echo -e "${green}All data-plane pods in ${NS} have ISTIO_AGENT_DUAL_STACK enabled${clr}"

echo
echo '***********************************'
echo ' Service definitions               '
echo '***********************************'
svcs=$(kubectl get svc -n "${NS}" --sort-by=.metadata.name --no-headers --template '{{range .items}}{{.metadata.name}}{{"\n"}}{{end}}')
for svc in ${svcs}; do
  name=$(<<<"${svc}" cut -f1)
  # shellcheck disable=2016
  ipFamilies=$(kubectl get svc -n "${NS}" "${name}" --template '{{range $f := .spec.ipFamilies}}{{$f}}{{"\n"}}{{end}}')
  families="["
  for ip in ${ipFamilies}; do
    families="${families} ${ip}"
  done
  families="${families} ]"

  # shellcheck disable=2016
  vips=$(kubectl get svc -n "${NS}" "${name}" --template '{{range $f := .spec.clusterIPs}}{{$f}}{{"\n"}}{{end}}')
  clusterips="["
  for ip in ${vips}; do
    clusterips="${clusterips} ${ip}"
  done
  clusterips="${clusterips} ]"

  ports="["
  # shellcheck disable=2016
  svcports=$(kubectl get svc -n "${NS}" "${name}" --template '{{range $p := .spec.ports}}{{$p.port}}/{{$p.protocol}}{{"\n"}}{{end}}')
  for port in ${svcports}; do
    ports="${ports} ${port}"
  done
  ports="${ports} ]"

  echo "Service ${NS}/${name}..."
  echo "    ipFamilies : ${families}"
  echo "    clusterIPs : ${clusterips}"
  echo "    Ports defined: ${ports}"
done

echo
echo '***********************************'
echo ' Pod readiness                     '
echo '***********************************'
for pod in ${pods}; do
  name=$(<<<"${pod}" cut -f1)
  echo "Checking ${NS}/${name}..."
  podips="$(kubectl get pods "${pod}" -n "${NS}" --template '{{range .status.podIPs}}{{.ip}} {{end}}')"
  ipv4=false
  ipv6=false
  for podip in ${podips}; do
    if [[ "${podip}" == *":"* ]]; then
      ipv6=true
    elif [[ "${podip}" == *"."* ]]; then
      ipv4=true
    fi
  done
  if [ ! ${ipv4} ] || [ ! $ipv6 ]; then
    echo -e "  ${red}Pod does not have IPv4 and IPv6 status.podIPs: [ ${podips} ]${clr}"
    echo -e "  ${red}Please restart/delete this pod${clr}"
    exit 1
  fi

  debug=false
  images=$(kubectl get pods -n "${NS}" "${pod}" --template '{{range .spec.containers}}{{.image}} {{end}}')
  for image in ${images}; do
    if [[ "${image}" == *"proxyv2-debug"* ]]; then
      debug=true
      break
    fi
  done

  if [[ "$debug" == "false" ]]; then
    echo -e "  ${yellow}cannot inspect ports since proxyv2-debug is not used${clr}"
    echo
    continue
  fi

  ports="$(istioctl proxy-config cluster "${name}.${NS}" --direction=inbound -ojson | grep '"name": "inbound' | awk -F\" '{print $4}' | cut -d'|' -f2 | sort -u)"
  # shellcheck disable=2016
  listeners="$(kubectl exec "${name}" -n "${NS}" -c istio-proxy -- sh -c 'ss -ltn | awk '"'"'{print $4}'"'")"
  for port in ${ports}; do
    bind=$(<<<"${listeners}" grep "${port}" | head -n2 | sed "s/:${port}//")
    while IFS= read -r bind_address; do
      case "${bind_address}" in
        "")
          echo -e "  ${blue}Port ${port}: bind not found${clr}";;
        "*")
          echo -e "  ${blue}Port ${port}: '*' bind and is ready for IPv6 ipFamily${clr}";;
        "0.0.0.0")
          echo -e "  ${blue}Port ${port}: '0.0.0.0' bind and is ready for IPv4 ipFamily${clr}";;
        "[::]")
          echo -e "  ${blue}Port ${port}: '[::]' bind and is ready for IPv6 ipFamily${clr}";;
        *)
          echo -e "  ${blue}Port ${port}: other bind found (${bind})${clr}";;
      esac
    done <<< "${bind}"
  done
  echo
done
