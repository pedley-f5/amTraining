#!/bin/bash

set -Eeuo pipefail

TOOLS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" &> /dev/null && pwd)"

registry_repo=${registry_repo:-}
if [ -z "$registry_repo" ]; then
    echo "registry_repo must be defined"
    exit 1
fi

images_used="$TOOLS_DIR/../images-used"

awk -F: '{if ($0 !~ "am-istio") {print $2}}' "$images_used" | while read -r image; do
    docker push "${registry_repo}:${image}"
done
echo "Done"
