#!/usr/bin/env bash

# To run this script you must pass in namespace where you want to check
# if the pods running in it are using a debug proxyv2 image or not.
#
# By default this script will check to see if the pods are running a proxyv2-debug
# image. If you wish to check that they are running the standard images please
# see the usage below.
#
# Usage: list-proxy-images.sh <namespaceName> <standard|debug(default)>
# Dependencies on host: kubectl

red='\x1B[0;31m'
green='\x1B[0;32m'
clr='\x1B[0m'

if ! command -v kubectl --help &> /dev/null
then
    echo "kubectl could not be found"
    exit 1
fi

NS=default
if [ "$1" != "" ]
then
  NS=${1}
fi

check=${2:-"debug"}
if [ "$check" != "debug" ] && [ "$2" != "standard" ] 
then
  echo "Invalid argument. Second argument needs to be either 'debug', 'standard', or empty"
  echo "User passed in ${2}"
  exit 1
fi


namespaceStatus=$(kubectl get ns "${NS}" --template '{{.status.phase}}')
if [ "$namespaceStatus" != "Active" ]
then
  echo "Namespace ${NS} is not present. Exiting..."
  exit 1
fi

pods="$(kubectl get pods -l security.istio.io/tlsMode=istio -n "${NS}" --template '{{range .items}}{{.metadata.name}} {{end}}')"
for pod in ${pods}; do
  name=$(<<<"${pod}" cut -f1)
  echo "Checking ${NS}/${name}:"

  images=$(kubectl get pods -n "${NS}" "${pod}" --template '{{range .spec.containers}}{{.image}} {{end}}')
  for image in ${images}; do
    if [[ "${image}" == *"proxyv2"* ]]; then
      if [[ "${image}" == *"proxyv2-debug"* ]]; then
	if [[ "${check}" == "standard" ]]; then
          echo -e "  ${red}debug proxyv2 image found${clr}"
          echo -e "  ${red}please restart pod${clr}"
	  continue 2
	fi
      else
	if [[ "${check}" == "debug" ]]; then
          echo -e "  ${red}standard proxyv2 image found${clr}"
          echo -e "  ${red}please restart pod${clr}"
	  continue 2
	fi
      fi
    fi
  done
  echo -e "  ${green}has expected proxyv2 image type${clr}"
done
