#!/bin/bash

set -Eeuo pipefail

TOOLS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" &> /dev/null && pwd)"

registry_repo=${registry_repo:-}
if [ -z "$registry_repo" ]; then
    echo "registry_repo must be defined"
    exit 1
fi

images_used="$TOOLS_DIR/../images-used"
repo_name=$(grep -v "am-istio" "$images_used" \
    | cut -d "/" -f3 | cut -d ":" -f1 | head -1)

awk -F: '{print $2}' "$images_used" | xargs -L1 -I{} \
   docker tag "quay.io/aspenmesh/${repo_name}:{}" "${registry_repo}:{}"
grep proxyv2 "$images_used" | awk -F: '{print $2}' | xargs -L1 -I{} \
   docker tag quay.io/aspenmesh/am-istio:{} "${registry_repo}:{}"
echo "Done"
