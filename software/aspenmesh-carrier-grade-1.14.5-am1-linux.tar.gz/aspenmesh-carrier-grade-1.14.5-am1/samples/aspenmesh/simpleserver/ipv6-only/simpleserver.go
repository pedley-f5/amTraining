package main

// Copyright 2022 Aspen Mesh
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import (
	"fmt"
	"log"
	"net"
	"net/http"
	"os"
	"os/signal"
	"syscall"
)

func headers(w http.ResponseWriter, req *http.Request) {
	for name, headers := range req.Header {
		for _, h := range headers {
			fmt.Fprintf(w, "%v: %v\n", name, h)
		}
	}

	fmt.Fprintf(w, "remote addr: %v\n", req.RemoteAddr)
	fmt.Fprintf(w, "host addr: %v\n", req.Host)
}

func main() {
	log.Println("Starting simpleserver")

	ipv6 := ipv6Handler{
		headersFunc: headers,
	}

	go func() {
		log.Println("Listening on [::]:8090")
		ListenAndServe("[::]:8090", "tcp6", ipv6)
	}()

	cancelChan := make(chan os.Signal, 1)
	signal.Notify(cancelChan, syscall.SIGTERM, syscall.SIGINT)
	sig := <-cancelChan
	log.Printf("Caught SIGTERM: %v", sig)
	log.Println("Exiting")
}

type ipv6Handler struct {
	headersFunc func(w http.ResponseWriter, req *http.Request)
}

func (i ipv6Handler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	log.Println("ipv6 connection")
	i.headersFunc(w, r)
	fmt.Fprintf(w, "ipv6 handler\n")
}

func ListenAndServe(addr, ipBind string, handler http.Handler) error {
	srv := &http.Server{Addr: addr, Handler: handler}
	ln, err := net.Listen(ipBind, addr)
	if err != nil {
		return err
	}
	return srv.Serve(ln)
}
