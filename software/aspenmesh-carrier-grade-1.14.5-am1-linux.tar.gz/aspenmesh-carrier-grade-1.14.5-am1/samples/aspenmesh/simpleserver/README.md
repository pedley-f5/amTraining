The simpleserver service is a service created by Aspen Mesh to validate native proper dual-stack behavior.

The following table shows how simpleserver will respond to requests to it over port 8090. Depending on the
socket that accepts the request (IPv4 or IPv6) it will echo back to the user a message how the request
was satisfied.

| Directory | Application listens on | Requests to service on port 8090 will report                         |
|-----------|------------------------|----------------------------------------------------------------------|
| dualstack | :: and 0.0.0.0         | ipv4-only or ipv6-only depending on what address served this request |
| ipv4-only | 0.0.0.0                | ipv4-only                                                            |
| ipv6-only | ::                     | ipv6-only                                                            |

All source code, Dockerfiles and  Makefiles are included if you wish to build your own image.

Only docker is required to build.

How to build:

1. Enter the directory you wish to build simpleserver for (e.g. dual-stack)
	```bash
	$ cd dual-stack
	```
2. Build the docker image based on the directory name
	```bash
	$ docker build -t simpleserver:dual-stack .
	...
